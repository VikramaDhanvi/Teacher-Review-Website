CREATE DATABASE teacher_review_system;

USE teacher_review_system;

-- Create a table for storing teacher data
CREATE TABLE teachers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    photo VARCHAR(255) NOT NULL
);

-- Create a table for storing comments
CREATE TABLE comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    teacher_id INT,
    text TEXT NOT NULL,
    FOREIGN KEY (teacher_id) REFERENCES teachers(id)
);
