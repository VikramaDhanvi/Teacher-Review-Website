<?php
include 'database.php';

$sql = "SELECT t.id, t.name, t.photo, c.id AS comment_id, c.text
        FROM teachers t
        LEFT JOIN comments c ON t.id = c.teacher_id";
$result = $conn->query($sql);

$teachers = [];
while ($row = $result->fetch_assoc()) {
    $teacher_id = $row['id'];
    if (!isset($teachers[$teacher_id])) {
        $teachers[$teacher_id] = [
            'id' => $row['id'],
            'name' => $row['name'],
            'photo' => $row['photo'],
            'comments' => []
        ];
    }
    
    if ($row['comment_id']) {
        $teachers[$teacher_id]['comments'][] = [
            'id' => $row['comment_id'],
            'text' => $row['text']
        ];
    }
}

echo json_encode(array_values($teachers));

$conn->close();
?>
