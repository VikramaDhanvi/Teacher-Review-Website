<?php
// Include database connection
include 'database.php';

// Check if the request is a POST request (i.e., a form submission)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the submitted data from the form
    $teacher_id = $_POST['teacher_id'];
    $comment = $_POST['comment'];

    // Basic validation
    if (empty($teacher_id) || empty($comment)) {
        echo "Error: Teacher ID and Comment cannot be empty.";
        exit();
    }

    // Prepare the SQL query to insert the comment
    $sql = "INSERT INTO comments (teacher_id, text) VALUES (?, ?)";

    // Use prepared statements to prevent SQL injection
    if ($stmt = $conn->prepare($sql)) {
        // Bind the parameters to the query
        $stmt->bind_param('is', $teacher_id, $comment);

        // Execute the query
        if ($stmt->execute()) {
            // Redirect back to the teacher list after successfully adding the comment
            header("Location: ../list_teachers.html?message=CommentAdded");
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the prepared statement
        $stmt->close();
    } else {
        echo "Error: " . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>
