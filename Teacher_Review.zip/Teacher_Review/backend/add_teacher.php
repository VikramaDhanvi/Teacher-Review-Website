<?php
include 'database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $photo = $_FILES['photo'];

    // Check if the name already exists in the database
    $sql_check = "SELECT * FROM teachers WHERE name = ?";
    $stmt_check = $conn->prepare($sql_check);
    $stmt_check->bind_param("s", $name);
    $stmt_check->execute();
    $result = $stmt_check->get_result();

    if ($result->num_rows > 0) {
        // Name already exists, redirect back with error message
        echo "<script>
                alert('Error: Teacher with this name already exists!');
                window.location.href = '../frontend/creator_home.html';
              </script>";
    } else {
        // Handle file upload
        $target_dir = "../backend/uploads/";
        $target_file = $target_dir . basename($photo["name"]);
        move_uploaded_file($photo["tmp_name"], $target_file);

        // Insert teacher into database
        $sql = "INSERT INTO teachers (name, photo) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $name, $target_file);
        $stmt->execute();
        $stmt->close();

        // Redirect to creator home after successful insertion
        header('Location: ../frontend/creator_home.html');
    }

    // Close statement and connection
    $stmt_check->close();
    $conn->close();
}
?>
