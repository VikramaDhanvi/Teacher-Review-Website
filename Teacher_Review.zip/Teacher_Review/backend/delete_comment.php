<?php
include 'database.php';

// Get the comment ID from the request
$data = json_decode(file_get_contents('php://input'), true);
$comment_id = $data['comment_id'];

// Delete the comment from the database
$sql = "DELETE FROM comments WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $comment_id);
if ($stmt->execute()) {
    echo "Success";
} else {
    echo "Error";
}

$stmt->close();
?>
