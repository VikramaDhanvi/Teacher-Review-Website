<?php
include 'database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $teacher_id = $_POST['teacher_id'];

    // Delete associated comments
    $sql = "DELETE FROM comments WHERE teacher_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $teacher_id);
    $stmt->execute();

    // Delete teacher
    $sql = "DELETE FROM teachers WHERE id = ?";
    $stmt->prepare($sql);
    $stmt->bind_param("i", $teacher_id);
    $stmt->execute();
    
    $stmt->close();
    header('Location: ../frontend/creator_home.html');
}
?>
