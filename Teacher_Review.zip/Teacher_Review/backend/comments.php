<?php
include 'database.php';

// Get the teacher_id from the query string
$teacher_id = $_GET['teacher_id'];

// Fetch the teacher details (optional)
$teacher_sql = "SELECT * FROM teachers WHERE id = $teacher_id";
$teacher_result = $conn->query($teacher_sql);
$teacher = $teacher_result->fetch_assoc();

// Fetch comments for the specific teacher
$comments_sql = "SELECT * FROM comments WHERE teacher_id = $teacher_id";
$comments_result = $conn->query($comments_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comments for <?php echo htmlspecialchars($teacher['name']); ?> - Teacher Review System</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 20px;
        }
        h1 {
            font-size: 2.5em;
            margin-bottom: 20px;
            text-align: center;
            color: #2c3e50;
        }
        #comments {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        p {
            font-size: 1.1em;
            line-height: 1.6;
            margin: 10px 0;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #2980b9;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h1>Comments for <?php echo htmlspecialchars($teacher['name']); ?></h1>
    
    <div id="comments">
        <?php
        if ($comments_result->num_rows > 0) {
            while ($comment = $comments_result->fetch_assoc()) {
                echo "<p>" . htmlspecialchars($comment['text']) . "</p>";
            }
        } else {
            echo "<p>No comments available.</p>";
        }
        ?>
    </div>

    <a href="../frontend/list_teachers.html">Back to Teachers List</a>
</body>
</html>

<?php
$conn->close();
?>
